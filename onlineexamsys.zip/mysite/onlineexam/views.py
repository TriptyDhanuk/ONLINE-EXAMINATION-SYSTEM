from django.shortcuts import render
from django.db import connections
from django.shortcuts import redirect
from django.http import HttpResponse

def login(request):
    msg=request.GET.get("msg")
    return render(request,"login.html",{'msg':msg})

def logout(request):
    del request.session['sid']
    return redirect('/')

def result(request):
    marks=0
    i=1
    while(i<=5):
        if(request.POST.get(str(i))):
            marks=marks+int(request.POST.get(str(i)))
        i=i+1
    return HttpResponse("<h1>Your marks is: "+str(marks)+" out of 5<h1>")


def lc(request):
    cursor=connections['default'].cursor()
    email=request.POST.get("email")
    password=request.POST.get("password")
    sql="SELECT * FROM students WHERE email='"+str(email)+"' AND password='"+str(password)+"'"
    cursor.execute(sql)
    u=cursor.fetchall()
    if(len(u)>0):
        request.session['sid']=u[0][0]
        return redirect("/exam")
    else:
        return redirect("/?msg=Invalid login")


def exam(request):
    if 'sid' not in request.session:
        return redirect('/')
    else:
        return render(request,"dashboard.html")

def registration(request):
    return render(request,"reg.html")

def regins(request):
    cursor=connections['default'].cursor()
    name=request.POST.get("name")
    email=request.POST.get("email")
    stream=request.POST.get("stream")
    phone=request.POST.get("phone")
    password=request.POST.get("password")
    roll=request.POST.get("roll")

    ins="INSERT INTO students SET name='"+str(name)+"', email='"+str(email)+"', stream='"+str(stream)+"', phone='"+str(phone)+"', password='"+str(password)+"',roll='"+str(roll)+"'"
    cursor.execute(ins)
    return render(request,"regins.html")
# Create your views here.
